# stoat.js (vendored)

Stoat's JavaScript SDK, built from https://github.com/stoatchat/javascript-client-sdk at commit `06c97ed4db237446cfdaf7d280d12744108bc9e9`.
MIT licence (see LICENSE).

npm's releases lag behind what Stoat's own web app uses (it builds the SDK from source too).
Refresh it with `node scripts/update-sdk.mjs`.
