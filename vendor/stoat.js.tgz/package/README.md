# stoat.js (vendored)

Stoat's JavaScript SDK, built from https://github.com/stoatchat/javascript-client-sdk at commit `4cb09a1b63a098f1ddb45237e07b435c1ecc71c8`.
MIT licence (see LICENSE).

npm's newest release (7.3.6) is behind what Stoat's own web app uses (it builds the SDK from source too).
This copy adds slowmode, newer permissions and events. Refresh it with `node scripts/update-sdk.mjs`.
