import { ReactiveSet } from "@solid-primitives/set";
import type { ChannelUnread } from "stoat-api";
import type { Merge } from "../lib/merge.js";
import type { Hydrate } from "./index.js";
export type HydratedChannelUnread = {
    id: string;
    lastMessageId?: string;
    messageMentionIds: ReactiveSet<string>;
};
export declare const channelUnreadHydration: Hydrate<Merge<ChannelUnread>, HydratedChannelUnread>;
//# sourceMappingURL=channelUnread.d.ts.map