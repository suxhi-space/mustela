import type { User as APIUser, BotInformation, RelationshipStatus, UserStatus } from "stoat-api";
import { File } from "../classes/File.js";
import type { Hydrate } from "./index.js";
export type HydratedUser = {
    id: string;
    username: string;
    discriminator: string;
    displayName?: string;
    relationship: RelationshipStatus;
    relations: null;
    online: boolean;
    privileged: boolean;
    badges: UserBadges;
    flags: UserFlags;
    avatar?: File;
    pronouns?: string;
    status?: UserStatus;
    bot?: BotInformation;
};
export declare const userHydration: Hydrate<APIUser, HydratedUser>;
/**
 * Badges available to users
 */
export declare enum UserBadges {
    Developer = 1,
    Translator = 2,
    Supporter = 4,
    ResponsibleDisclosure = 8,
    Founder = 16,
    PlatformModeration = 32,
    ActiveSupporter = 64,
    Paw = 128,
    EarlyAdopter = 256,
    ReservedRelevantJokeBadge1 = 512,
    ReservedRelevantJokeBadge2 = 1024
}
/**
 * Flags attributed to users
 */
export declare enum UserFlags {
    Suspended = 1,
    Deleted = 2,
    Banned = 4
}
//# sourceMappingURL=user.d.ts.map