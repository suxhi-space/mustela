import type { Member as APIMember, MemberCompositeKey } from "stoat-api";
import { File } from "../classes/File.js";
import type { Merge } from "../lib/merge.js";
import type { Hydrate } from "./index.js";
export type HydratedServerMember = {
    id: MemberCompositeKey;
    joinedAt: Date;
    nickname?: string;
    avatar?: File;
    pronouns?: string;
    roles: string[];
    timeout?: Date;
};
export declare const serverMemberHydration: Hydrate<Merge<APIMember>, HydratedServerMember>;
//# sourceMappingURL=serverMember.d.ts.map