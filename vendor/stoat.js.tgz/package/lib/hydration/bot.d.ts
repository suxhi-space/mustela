import type { Bot as APIBot } from "stoat-api";
import type { Hydrate } from "./index.js";
export type HydratedBot = {
    id: string;
    ownerId: string;
    token: string;
    public: boolean;
    analytics: boolean;
    discoverable: boolean;
    interactionsUrl?: string;
    termsOfServiceUrl?: string;
    privacyPolicyUrl?: string;
    flags: BotFlags;
};
export declare const botHydration: Hydrate<APIBot, HydratedBot>;
/**
 * Flags attributed to users
 */
export declare enum BotFlags {
}
//# sourceMappingURL=bot.d.ts.map