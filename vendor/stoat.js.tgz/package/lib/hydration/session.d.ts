import type { SessionInfo as APISession } from "stoat-api";
import type { Hydrate } from "./index.js";
export type HydratedSession = {
    id: string;
    name: string;
};
export declare const sessionHydration: Hydrate<APISession, HydratedSession>;
//# sourceMappingURL=session.d.ts.map