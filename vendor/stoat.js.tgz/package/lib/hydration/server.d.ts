import { ReactiveMap } from "@solid-primitives/map";
import { ReactiveSet } from "@solid-primitives/set";
import type { Server as APIServer, Category, SystemMessageChannels } from "stoat-api";
import { File } from "../classes/File.js";
import { ServerRole } from "../classes/ServerRole.js";
import type { Hydrate } from "./index.js";
export type HydratedServer = {
    id: string;
    ownerId: string;
    name: string;
    description?: string;
    icon?: File;
    banner?: File;
    channelIds: ReactiveSet<string>;
    categories?: Category[];
    systemMessages?: SystemMessageChannels;
    roles: ReactiveMap<string, ServerRole>;
    defaultPermissions: bigint;
    flags: ServerFlags;
    analytics: boolean;
    discoverable: boolean;
    nsfw: boolean;
    approximateMemberCount: number;
};
export declare const serverHydration: Hydrate<APIServer, HydratedServer>;
/**
 * Flags attributed to servers
 */
export declare enum ServerFlags {
    Official = 1,
    Verified = 2
}
//# sourceMappingURL=server.d.ts.map