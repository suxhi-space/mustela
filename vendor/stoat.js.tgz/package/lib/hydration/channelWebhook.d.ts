import type { Webhook } from "stoat-api";
import { File } from "../classes/File.js";
import type { Merge } from "../lib/merge.js";
import type { Hydrate } from "./index.js";
export type HydratedChannelWebhook = {
    id: string;
    name: string;
    avatar?: File;
    channelId: string;
    token: string;
};
export declare const channelWebhookHydration: Hydrate<Merge<Webhook>, HydratedChannelWebhook>;
//# sourceMappingURL=channelWebhook.d.ts.map