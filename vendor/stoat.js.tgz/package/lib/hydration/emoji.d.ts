import type { Emoji as APIEmoji, EmojiParent } from "stoat-api";
import type { Merge } from "../lib/merge.js";
import type { Hydrate } from "./index.js";
export type HydratedEmoji = {
    id: string;
    parent: EmojiParent;
    creatorId: string;
    name: string;
    animated: boolean;
    nsfw: boolean;
};
export declare const emojiHydration: Hydrate<Merge<APIEmoji>, HydratedEmoji>;
//# sourceMappingURL=emoji.d.ts.map