import type { BannedUser as APIBannedUser, ServerBan as APIServerBan, MemberCompositeKey } from "stoat-api";
import type { Client } from "../Client.js";
import { BannedUser } from "./BannedUser.js";
import type { Server } from "./Server.js";
/**
 * Server Ban
 */
export declare class ServerBan {
    protected client: Client;
    readonly id: MemberCompositeKey;
    readonly reason?: string;
    readonly user?: BannedUser;
    /**
     * Construct Server Ban
     * @param client Client
     * @param data Data
     */
    constructor(client: Client, data: APIServerBan, user?: APIBannedUser);
    /**
     * Server
     */
    get server(): Server | undefined;
    /**
     * Remove this server ban
     */
    pardon(): Promise<void>;
}
//# sourceMappingURL=ServerBan.d.ts.map