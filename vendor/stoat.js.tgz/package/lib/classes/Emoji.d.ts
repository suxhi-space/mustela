import type { DataEditEmoji, EmojiParent } from "stoat-api";
import type { EmojiCollection } from "../collections/EmojiCollection.js";
import type { User } from "./User.js";
/**
 * Emoji Class
 */
export declare class Emoji {
    #private;
    readonly id: string;
    /**
     * Construct Emoji
     * @param collection Collection
     * @param id Emoji Id
     */
    constructor(collection: EmojiCollection, id: string);
    /**
     * Convert to string
     * @returns String
     */
    toString(): string;
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Time when this emoji was created
     */
    get createdAt(): Date;
    /**
     * Information about the parent of this emoji
     */
    get parent(): EmojiParent;
    /**
     * Creator of the emoji
     */
    get creator(): User | undefined;
    /**
     * Name
     */
    get name(): string;
    /**
     * Whether the emoji is animated
     */
    get animated(): boolean;
    /**
     * Whether the emoji is marked as mature
     */
    get mature(): boolean;
    /**
     * URL to emoji
     */
    get url(): string;
    edit(data: DataEditEmoji): Promise<void>;
    /**
     * Delete Emoji
     */
    delete(): Promise<void>;
}
//# sourceMappingURL=Emoji.d.ts.map