import { Accessor } from "solid-js";
import type { Client } from "../Client.js";
import { UserVoiceState } from "../events/v1.js";
/**
 * The voice status of an entity. Screenshare supersedes video, video supersedes voice, and voice supersedes none.
 */
export type VoiceStatus = "none" | "voice" | "video" | "screenshare";
/**
 * Voice Participant
 */
export declare class VoiceParticipant {
    #private;
    protected client: Client;
    readonly userId: string;
    readonly joinedAt: Date;
    readonly isReceiving: Accessor<boolean>;
    readonly isPublishing: Accessor<boolean>;
    readonly isScreensharing: Accessor<boolean>;
    readonly isCamera: Accessor<boolean>;
    /**
     * Construct Server Ban
     * @param client Client
     * @param data Data
     */
    constructor(client: Client, data: UserVoiceState);
    /**
     * Update the state
     * @param data Data
     */
    update(data: Partial<UserVoiceState>): void;
    /**
     * The voice status of a participant. Screenshare supersedes video, video supersedes voice, and voice supersedes none.
     */
    get voiceStatus(): VoiceStatus;
}
//# sourceMappingURL=VoiceParticipant.d.ts.map