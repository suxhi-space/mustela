import type { DataBanCreate, DataMemberEdit, MemberCompositeKey } from "stoat-api";
import type { ServerMemberCollection } from "../collections/ServerMemberCollection.js";
import { Permission } from "../permissions/definitions.js";
import type { Channel } from "./Channel.js";
import type { File } from "./File.js";
import type { Server } from "./Server.js";
import { ServerRole } from "./ServerRole.js";
import type { User } from "./User.js";
/**
 * Server Member Class
 */
export declare class ServerMember {
    #private;
    readonly id: MemberCompositeKey;
    /**
     * Construct Server Member
     * @param collection Collection
     * @param id Id
     */
    constructor(collection: ServerMemberCollection, id: MemberCompositeKey);
    /**
     * Convert to string
     * @returns String
     */
    toString(): string;
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Server this member belongs to
     */
    get server(): Server | undefined;
    /**
     * User corresponding to this member
     */
    get user(): User | undefined;
    /**
     * When this user joined the server
     */
    get joinedAt(): Date;
    /**
     * Nickname
     */
    get nickname(): string | undefined;
    /**
     * Avatar
     */
    get avatar(): File | undefined;
    /**
     * Pronouns
     */
    get pronouns(): string | undefined;
    /**
     * List of role IDs
     */
    get roles(): string[];
    /**
     * Time at which timeout expires
     */
    get timeout(): Date | undefined;
    /**
     * Ordered list of roles for this member, from lowest to highest priority.
     */
    get orderedRoles(): ServerRole[];
    /**
     * Member's currently hoisted role.
     */
    get hoistedRole(): ServerRole | null;
    /**
     * Member's current role colour.
     */
    get roleColour(): string | null | undefined;
    /**
     * Member's current role icon with name.
     */
    get iconRole(): ServerRole | null | undefined;
    /**
     * Member's ranking
     * Smaller values are ranked as higher priority
     */
    get ranking(): number;
    /**
     * Get the permissions that this member has against a certain object
     * @param target Target object to check permissions against
     * @returns Permissions that this member has
     */
    getPermissions(target: Server | Channel): bigint;
    /**
     * Check whether a member has a certain permission against a certain object
     * @param target Target object to check permissions against
     * @param permission Permission names to check for
     * @returns Whether the member has this permission
     */
    hasPermission(target: Server | Channel, ...permission: (keyof typeof Permission)[]): boolean;
    /**
     * Checks whether the target member has a higher rank than this member.
     * @param target The member to compare against
     * @returns Whether this member is inferior to the target
     */
    inferiorTo(target: ServerMember): boolean;
    /**
     * Display name
     */
    get displayName(): string | undefined;
    /**
     * URL to the member's avatar
     */
    get avatarURL(): string | undefined;
    /**
     * URL to the member's animated avatar
     */
    get animatedAvatarURL(): string | undefined;
    /**
     * Edit a member
     * @param data Changes
     */
    edit(data: DataMemberEdit): Promise<void>;
    /**
     * Ban this member from the server
     * @param options Ban options
     */
    ban(options: DataBanCreate): Promise<void>;
    /**
     * Kick this member from the server
     */
    kick(): Promise<void>;
    /**
     * Timeout this member until the given date
     * @param date ISO8601 timestamp to time out until
     */
    setTimeout(date: string): Promise<void>;
    /**
     * Remove this member's timeout
     */
    removeTimeout(): Promise<void>;
}
//# sourceMappingURL=ServerMember.d.ts.map