import type { Invite } from "stoat-api";
import type { Client } from "../Client.js";
import type { Channel } from "./Channel.js";
import type { Server } from "./Server.js";
import type { User } from "./User.js";
/**
 * Channel Invite
 */
export declare abstract class ChannelInvite {
    protected client?: Client;
    readonly type: Invite["type"] | "None";
    /**
     * Construct Channel Invite
     * @param client Client
     * @param type Type
     */
    constructor(client?: Client, type?: Invite["type"] | "None");
    /**
     * Create an Invite from an API Invite
     * @param client Client
     * @param invite Data
     * @returns Invite
     */
    static from(client: Client, invite: Invite): ChannelInvite;
}
/**
 * Invite of unknown type
 */
export declare class UnknownInvite extends ChannelInvite {
}
/**
 * Server Invite
 */
export declare class ServerInvite extends ChannelInvite {
    readonly id: string;
    readonly creatorId: string;
    readonly serverId: string;
    readonly channelId: string;
    /**
     * Construct Server Invite
     * @param client Client
     * @param invite Invite
     */
    constructor(client: Client, invite: Invite & {
        type: "Server";
    });
    /**
     * Creator of the invite
     */
    get creator(): User | undefined;
    /**
     * Server this invite points to
     */
    get server(): Server | undefined;
    /**
     * Channel this invite points to
     */
    get channel(): Channel | undefined;
    /**
     * Delete the invite
     */
    delete(): Promise<void>;
}
//# sourceMappingURL=Invite.d.ts.map