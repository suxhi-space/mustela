import type { SetStoreFunction } from "solid-js/store";
import type { MFAMethod, MFAResponse, MultiFactorStatus, MFATicket as TicketType } from "stoat-api";
import type { Client } from "../Client.js";
/**
 * Multi-Factor Authentication
 */
export declare class MFA {
    #private;
    /**
     * Construct MFA helper
     * @param client Client
     * @param state State
     */
    constructor(client: Client, state: MultiFactorStatus);
    /**
     * Whether authenticator app is enabled
     */
    get authenticatorEnabled(): boolean;
    /**
     * Whether recovery codes are enabled
     */
    get recoveryEnabled(): boolean;
    /**
     * Available MFA methods for generating tickets
     */
    get availableMethods(): MFAMethod[];
    /**
     * Create an MFA ticket
     * @param params
     * @returns Token
     */
    createTicket(params: MFAResponse): Promise<MFATicket>;
    /**
     * Enable authenticator using token generated from secret found earlier
     * @param token Token
     */
    enableAuthenticator(token: string): Promise<void>;
}
/**
 * MFA Ticket
 */
export declare class MFATicket {
    #private;
    /**
     * Construct MFA Ticket
     * @param client Client
     * @param ticket Ticket
     * @param mutate Mutate the store
     */
    constructor(client: Client, ticket: TicketType, mutate: SetStoreFunction<MultiFactorStatus>);
    /**
     * Token
     */
    get token(): string;
    /**
     * @internal
     * Use this ticket
     */
    _consume(): void;
    /**
     * Fetch recovery codes
     * @returns List of codes
     */
    fetchRecoveryCodes(): Promise<string[]>;
    /**
     * Generate new set of recovery codes
     * @returns List of codes
     */
    generateRecoveryCodes(): Promise<string[]>;
    /**
     * Generate new authenticator secret
     * @returns Secret
     */
    generateAuthenticatorSecret(): Promise<string>;
    /**
     * Disable authenticator
     */
    disableAuthenticator(): Promise<void>;
    /**
     * Disable account
     */
    disableAccount(): Promise<void>;
    /**
     * Delete account
     */
    deleteAccount(): Promise<void>;
}
//# sourceMappingURL=MFA.d.ts.map