import { Accessor } from "solid-js";
import { ReactiveMap } from "@solid-primitives/map";
import type { ReactiveSet } from "@solid-primitives/set";
import type { Channel as APIChannel, DataEditChannel, DataMessageSearch, DataMessageSend, Invite, Override } from "stoat-api";
import type { APIRoutes } from "stoat-api";
import { ChannelCollection } from "../collections/index.js";
import { UserSlowmodes } from "../events/v1.js";
import { Permission } from "../permissions/definitions.js";
import type { ChannelWebhook } from "./ChannelWebhook.js";
import type { File } from "./File.js";
import type { Message } from "./Message.js";
import type { Server } from "./Server.js";
import type { ServerMember } from "./ServerMember.js";
import type { User } from "./User.js";
import { VoiceParticipant, VoiceStatus } from "./VoiceParticipant.js";
/**
 * Channel Class
 */
export declare class Channel {
    #private;
    readonly id: string;
    _typingTimers: Record<string, number>;
    voiceParticipants: ReactiveMap<string, VoiceParticipant>;
    readonly userSlowmode: Accessor<UserSlowmodes | undefined>;
    /**
     * Construct Channel
     * @param collection Collection
     * @param id Channel Id
     */
    constructor(collection: ChannelCollection, id: string);
    /**
     * Write to string as a channel mention
     * @returns Formatted String
     */
    toString(): string;
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Time when this server was created
     */
    get createdAt(): Date;
    /**
     * Channel type
     */
    get type(): APIChannel["channel_type"];
    /**
     * Absolute pathname to this channel in the client
     */
    get path(): string;
    /**
     * URL to this channel
     */
    get url(): string;
    /**
     * Channel name
     */
    get name(): string;
    /**
     * Display name
     */
    get displayName(): string | undefined;
    /**
     * Channel description
     */
    get description(): string | undefined;
    /**
     * Channel icon
     */
    get icon(): File | undefined;
    /**
     * Whether the conversation is active
     */
    get active(): boolean;
    /**
     * User ids of people currently typing in channel
     */
    get typingIds(): ReactiveSet<string>;
    /**
     * Users currently trying in channel
     */
    get typing(): User[];
    /**
     * User ids of recipients of the group
     */
    get recipientIds(): ReactiveSet<string>;
    /**
     * Recipients of the group
     */
    get recipients(): User[];
    /**
     * Find recipient of this DM
     */
    get recipient(): User | undefined;
    /**
     * User ID
     */
    get userId(): string;
    /**
     * User this channel belongs to
     */
    get user(): User | undefined;
    /**
     * Owner ID
     */
    get ownerId(): string;
    /**
     * Owner of the group
     */
    get owner(): User | undefined;
    /**
     * Server ID
     */
    get serverId(): string;
    /**
     * Server this channel is in
     */
    get server(): Server | undefined;
    /**
     * Permissions allowed for users in this group
     */
    get permissions(): bigint | undefined;
    /**
     * Default permissions for this server channel
     */
    get defaultPermissions(): {
        a: bigint;
        d: bigint;
    } | undefined;
    /**
     * Role permissions for this server channel
     */
    get rolePermissions(): Record<string, {
        a: bigint;
        d: bigint;
    }> | undefined;
    /**
     * Whether this channel is marked as mature
     */
    get mature(): boolean;
    /**
     * ID of the last message sent in this channel
     */
    get lastMessageId(): string | undefined;
    /**
     * Last message sent in this channel
     */
    get lastMessage(): Message | undefined;
    /**
     * Time when the last message was sent
     */
    get lastMessageAt(): Date | undefined;
    /**
     * Time when the channel was last updated (either created or a message was sent)
     */
    get updatedAt(): Date;
    /**
     * Whether this channel is unread
     */
    get unread(): boolean;
    /**
     * Whether this channel is muted
     */
    get muted(): boolean;
    /**
     * Get mentions in this channel for user.
     */
    get mentions(): ReactiveSet<string> | undefined;
    /**
     * Whether this is a 'voice chats v2' channel
     *
     * NB. subject to change as vc(2) goes to production
     */
    get isVoice(): boolean;
    /**
     * URL to the channel icon
     */
    get iconURL(): string | undefined;
    /**
     * URL to the animated channel icon
     */
    get animatedIconURL(): string | undefined;
    /**
     * Whether this channel may be hidden to some users
     */
    get potentiallyRestrictedChannel(): string | boolean | undefined;
    /**
     * Permission the currently authenticated user has against this channel
     */
    get permission(): bigint;
    /**
     * Check whether we have a given permission in a channel
     * @param permission Permission Names
     * @returns Whether we have this permission
     */
    havePermission(...permission: (keyof typeof Permission)[]): boolean;
    /**
     * Check whether we have at least one of the given permissions in a channel
     * @param permission Permission Names
     * @returns Whether we have one of the permissions
     */
    orPermission(...permission: (keyof typeof Permission)[]): boolean;
    /**
     * Fetch a channel's members.
     * @requires `Group`
     * @returns An array of the channel's members.
     */
    fetchMembers(): Promise<User[]>;
    /**
     * Create a webhook
     * @param name Webhook name
     * @returns The newly-created webhook
     */
    createWebhook(name: string): Promise<ChannelWebhook>;
    /**
     * Fetch a channel's webhooks
     * @requires `TextChannel`, `Group`
     * @returns Webhooks
     */
    fetchWebhooks(): Promise<ChannelWebhook[]>;
    /**
     * Edit a channel
     * @param data Changes
     */
    edit(data: DataEditChannel): Promise<void>;
    /**
     * Delete or leave a channel
     * @param leaveSilently Whether to not send a message on leave
     * @requires `DirectMessage`, `Group`, `TextChannel`
     */
    delete(leaveSilently?: boolean): Promise<void>;
    /**
     * Add a user to a group
     * @param user_id ID of the target user
     * @requires `Group`
     */
    addMember(user_id: string): Promise<void>;
    /**
     * Remove a user from a group
     * @param user_id ID of the target user
     * @requires `Group`
     */
    removeMember(user_id: string): Promise<void>;
    /**
     * Send a message
     * @param data Either the message as a string or message sending route data
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     * @returns Sent message
     */
    sendMessage(data: string | DataMessageSend, idempotencyKey?: string): Promise<Message>;
    /**
     * Fetch a message by its ID
     * @param messageId ID of the target message
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     * @returns Message
     */
    fetchMessage(messageId: string): Promise<Message>;
    /**
     * Fetch multiple messages from a channel
     * @param params Message fetching route data
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     * @returns Messages
     */
    fetchMessages(params?: Omit<(APIRoutes & {
        method: "get";
        path: "/channels/{target}/messages";
    })["params"], "include_users">): Promise<Message[]>;
    /**
     * Fetch multiple messages from a channel including the users that sent them
     * @param params Message fetching route data
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     * @returns Object including messages and users
     */
    fetchMessagesWithUsers(params?: Omit<(APIRoutes & {
        method: "get";
        path: "/channels/{target}/messages";
    })["params"], "include_users">): Promise<{
        messages: Message[];
        users: User[];
        members: ServerMember[] | undefined;
    }>;
    /**
     * Search for messages
     * @param params Message searching route data
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     * @returns Messages
     */
    search(params: Omit<DataMessageSearch, "include_users">): Promise<Message[]>;
    /**
     * Search for messages including the users that sent them
     * @param params Message searching route data
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     * @returns Object including messages and users
     */
    searchWithUsers(params: Omit<DataMessageSearch, "include_users">): Promise<{
        messages: Message[];
        users: User[];
        members: ServerMember[] | undefined;
    }>;
    /**
     * Delete many messages by their IDs
     * @param ids List of message IDs
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     */
    deleteMessages(ids: string[]): Promise<void>;
    /**
     * Create an invite to the channel
     * @requires `TextChannel`
     * @returns Newly created invite code
     */
    createInvite(): Promise<Invite>;
    /**
     * Mark a channel as read
     * @param message Last read message or its ID
     * @param skipRateLimiter Whether to skip the internal rate limiter
     * @param skipRequest For internal updates only
     * @param skipNextMarking For internal usage only
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     */
    ack(message?: Message | string, skipRateLimiter?: boolean, skipRequest?: boolean, skipNextMarking?: boolean): Promise<void>;
    /**
     * Set role permissions
     * @param role_id Role Id, set to 'default' to affect all users
     * @param permissions Permission value
     * @requires `Group`, `TextChannel`
     */
    setPermissions(role_id: string | undefined, permissions: Override | number): Promise<APIChannel>;
    /**
     * Get slowmode value for the channel
     */
    get slowmode(): number;
    /**
     * Join a call
     * @param node Target node
     * @param forceDisconnect Whether to disconnect existing call
     * @param recipients Ring targets
     * @returns LiveKit URL and Token
     */
    joinCall(node?: string, forceDisconnect?: boolean, recipients?: (User | string)[]): Promise<{
        token: string;
        url: string;
    }>;
    /**
     * Start typing in this channel
     * @requires `DirectMessage`, `Group`, `TextChannel`
     */
    startTyping(): void;
    /**
     * Stop typing in this channel
     * @requires `DirectMessage`, `Group`, `TextChannel`
     */
    stopTyping(): void;
    /**
     * The voice status of a channel. Screenshare supersedes video, video
     * supersedes voice, and voice supersedes none. This getter takes the highest
     * priority status from all participants in the channel.
     */
    get voiceStatus(): VoiceStatus;
    setUserSlowmode(slowmode: UserSlowmodes): void;
}
//# sourceMappingURL=Channel.d.ts.map