import type { BannedUser as APIBannedUser } from "stoat-api";
import type { Client } from "../Client.js";
import { File } from "./File.js";
/**
 * Banned User
 */
export declare class BannedUser {
    readonly id: string;
    readonly avatar?: File;
    readonly username: string;
    readonly discriminator: string;
    /**
     * Construct Banned User
     * @param client Client
     * @param data Data
     */
    constructor(client: Client, data: APIBannedUser);
}
//# sourceMappingURL=BannedUser.d.ts.map