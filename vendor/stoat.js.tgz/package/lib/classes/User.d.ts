import type { User as APIUser, UserLimits as APIUserLimits, DataEditUser, Presence } from "stoat-api";
import type { UserCollection } from "../collections/UserCollection.js";
import type { Channel } from "./Channel.js";
import type { File } from "./File.js";
import { UserProfile } from "./UserProfile.js";
export type UserLimits = APIUserLimits;
/**
 * User Class
 */
export declare class User {
    #private;
    readonly id: string;
    /**
     * Construct User
     * @param collection Collection
     * @param id Id
     */
    constructor(collection: UserCollection, id: string);
    /**
     * Write to string as a user mention
     * @returns Formatted String
     */
    toString(): string;
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Time when this user created their account
     */
    get createdAt(): Date;
    /**
     * How old this user is in milliseconds
     */
    get age(): number;
    /**
     * Username
     */
    get username(): string;
    /**
     * Discriminator
     */
    get discriminator(): string;
    /**
     * Display Name
     */
    get displayName(): string;
    /**
     * Avatar
     */
    get avatar(): File | undefined;
    /**
     * Pronouns
     */
    get pronouns(): string | undefined;
    /**
     * Badges
     */
    get badges(): number;
    /**
     * User Status
     */
    get status(): {
        text?: string | null;
        presence?: Presence | null;
    } | undefined;
    /**
     * Relationship with user
     */
    get relationship(): string;
    /**
     * Whether the user is online
     */
    get online(): boolean;
    /**
     * Whether the user is privileged
     */
    get privileged(): boolean;
    /**
     * Flags
     */
    get flags(): number;
    /**
     * Bot information
     */
    get bot(): {
        owner: string;
    } | undefined;
    /**
     * Whether this user is ourselves
     */
    get self(): boolean;
    /**
     * URL to the user's default avatar
     */
    get defaultAvatarURL(): string;
    /**
     * URL to the user's avatar
     */
    get avatarURL(): string;
    /**
     * URL to the user's animated avatar
     */
    get animatedAvatarURL(): string;
    /**
     * Presence
     */
    get presence(): Presence;
    /**
     * Generate status message
     * @param translate Translation function
     * @returns Status message
     */
    statusMessage(translate?: (presence: Presence) => string): string | undefined;
    /**
     * Permissions against this user
     */
    get permission(): number;
    /**
     * Edit the user
     * @param data Changes
     */
    edit(data: DataEditUser): Promise<void>;
    /**
     * Change the username of the current user
     * @param username New username
     * @param password Current password
     */
    changeUsername(username: string, password: string): Promise<APIUser>;
    /**
     * Open a DM with a user
     * @returns DM Channel
     */
    openDM(): Promise<Channel>;
    /**
     * Send a friend request to a user
     */
    addFriend(): Promise<User>;
    /**
     * Remove a user from the friend list
     */
    removeFriend(): Promise<void>;
    /**
     * Block a user
     */
    blockUser(): Promise<void>;
    /**
     * Unblock a user
     */
    unblockUser(): Promise<void>;
    /**
     * Fetch the profile of a user
     * @returns The profile of the user
     */
    fetchProfile(): Promise<UserProfile>;
    /**
     * Fetch the mutual connections of the current user and a target user
     * @returns The mutual connections of the current user and a target user
     */
    fetchMutual(): Promise<{
        users: string[];
        servers: string[];
    }>;
    /**
     * Backend enforced limits for a user
     */
    get limits(): UserLimits | undefined;
}
//# sourceMappingURL=User.d.ts.map