import type { Message as APIMessage, SystemMessage as APISystemMessage } from "stoat-api";
import type { Client } from "../Client.js";
import type { User } from "./User.js";
import { Message } from "./index.js";
/**
 * System Message
 */
export declare abstract class SystemMessage {
    protected client?: Client;
    readonly type: APISystemMessage["type"];
    /**
     * Construct System Message
     * @param client Client
     * @param type Type
     */
    constructor(client: Client, type: APISystemMessage["type"]);
    /**
     * Create an System Message from an API System Message
     * @param client Client
     * @param embed Data
     * @returns System Message
     */
    static from(client: Client, parent: APIMessage, message: APISystemMessage): SystemMessage;
}
/**
 * Text System Message
 */
export declare class TextSystemMessage extends SystemMessage {
    readonly content: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "text";
    });
}
/**
 * User System Message
 */
export declare class UserSystemMessage extends SystemMessage {
    readonly userId: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "user_added" | "user_remove" | "user_joined" | "user_left" | "user_kicked" | "user_banned";
    });
    /**
     * User this message concerns
     */
    get user(): User | undefined;
}
/**
 * User Moderated System Message
 */
export declare class UserModeratedSystemMessage extends UserSystemMessage {
    readonly byId: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "user_added" | "user_remove";
    });
    /**
     * User this action was performed by
     */
    get by(): User | undefined;
}
/**
 * Channel Edit System Message
 */
export declare class ChannelEditSystemMessage extends SystemMessage {
    readonly byId: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "channel_renamed" | "channel_description_changed" | "channel_icon_changed";
    });
    /**
     * User this action was performed by
     */
    get by(): User | undefined;
}
/**
 * Channel Renamed System Message
 */
export declare class ChannelRenamedSystemMessage extends ChannelEditSystemMessage {
    readonly name: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "channel_renamed";
    });
}
/**
 * Channel Ownership Change System Message
 */
export declare class ChannelOwnershipChangeSystemMessage extends SystemMessage {
    readonly fromId: string;
    readonly toId: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "channel_ownership_changed";
    });
    /**
     * User giving away channel ownership
     */
    get from(): User | undefined;
    /**
     * User receiving channel ownership
     */
    get to(): User | undefined;
}
/**
 * Message Pinned System Message
 */
export declare class MessagePinnedSystemMessage extends SystemMessage {
    readonly messageId: string;
    readonly byId: string;
    /**
     * Construct System Message
     * @param client Client
     * @param systemMessage System Message
     */
    constructor(client: Client, systemMessage: APISystemMessage & {
        type: "message_pinned" | "message_unpinned";
    });
    /**
     * Message that was pinned/unpinned
     */
    get message(): Message | undefined;
    /**
     * User that pinned/unpinned
     */
    get by(): User | undefined;
}
/**
 * Call Started System Message
 */
export declare class CallStartedSystemMessage extends SystemMessage {
    readonly byId: string;
    readonly startedAt: Date;
    readonly finishedAt: Date | null;
    /**
     * Construct System Message
     * @param client Client
     * @param parent Message
     * @param systemMessage System Message
     */
    constructor(client: Client, parent: APIMessage, systemMessage: APISystemMessage & {
        type: "call_started";
    });
    /**
     * User that started the call
     */
    get by(): User | undefined;
}
//# sourceMappingURL=SystemMessage.d.ts.map