import type { ReactiveMap } from "@solid-primitives/map";
import type { ReactiveSet } from "@solid-primitives/set";
import type { APIRoutes, Server as APIServer, AuditLogEntry, Category, DataBanCreate, DataCreateEmoji, DataCreateServerChannel, DataEditRole, DataEditServer, DiscoverRequest, Override, Role } from "stoat-api";
import type { ServerCollection } from "../collections/ServerCollection.js";
import type { ServerFlags } from "../hydration/server.js";
import { Permission } from "../permissions/definitions.js";
import type { Channel } from "./Channel.js";
import type { Emoji } from "./Emoji.js";
import type { File } from "./File.js";
import { ChannelInvite } from "./Invite.js";
import { ServerBan } from "./ServerBan.js";
import { ServerMember } from "./ServerMember.js";
import { ServerRole } from "./ServerRole.js";
import { User } from "./User.js";
import { VoiceStatus } from "./VoiceParticipant.js";
/**
 * Server Class
 */
export declare class Server {
    #private;
    readonly id: string;
    /**
     * Construct Server
     * @param collection Collection
     * @param id Id
     */
    constructor(collection: ServerCollection, id: string);
    /**
     * Convert to string
     * @returns String
     */
    toString(): string;
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Time when this server was created
     */
    get createdAt(): Date;
    /**
     * Owner's user ID
     */
    get ownerId(): string;
    /**
     * Owner
     */
    get owner(): User | undefined;
    /**
     * Absolute pathname to this server in the client
     */
    get path(): string;
    /**
     * Name
     */
    get name(): string;
    /**
     * Description
     */
    get description(): string | undefined;
    /**
     * Icon
     */
    get icon(): File | undefined;
    /**
     * Banner
     */
    get banner(): File | undefined;
    /**
     * Channel IDs
     */
    get channelIds(): ReactiveSet<string>;
    /**
     * Channels
     */
    get channels(): Channel[];
    /**
     * Categories
     */
    get categories(): Category[] | undefined;
    /**
     * System message channels
     */
    get systemMessages(): APIServer["system_messages"];
    /**
     * Roles
     */
    get roles(): ReactiveMap<string, ServerRole>;
    /**
     * Default permissions
     */
    get defaultPermissions(): bigint;
    /**
     * Server flags
     */
    get flags(): ServerFlags;
    /**
     * Whether analytics are enabled for this server
     */
    get analytics(): boolean;
    /**
     * Whether this server is publicly discoverable
     */
    get discoverable(): boolean;
    /**
     * Approximate amount of members in this server
     */
    get approximateMemberCount(): number;
    /**
     * Whether this server is marked as mature
     */
    get mature(): boolean;
    /**
     * Get an array of ordered categories with their respective channels.
     * Uncategorised channels are returned in `id="default"` category.
     */
    get orderedChannels(): (Omit<Category, "channels"> & {
        channels: Channel[];
    })[];
    /**
     * Default channel for this server
     */
    get defaultChannel(): Channel | undefined;
    /**
     * Get an ordered array of roles with their IDs attached.
     * The highest ranking roles will be first followed by lower
     * ranking roles. This is dictated by the "rank" property
     * which is smaller for higher priority roles.
     */
    get orderedRoles(): ServerRole[];
    /**
     * Check whether the server is currently unread
     * @returns Whether the server is unread
     */
    get unread(): boolean;
    /**
     * Find all message IDs of unread messages
     * @returns Array of message IDs which are unread
     */
    get mentions(): string[];
    /**
     * URL to the server's icon
     */
    get iconURL(): string | undefined;
    /**
     * URL to the server's animated icon
     */
    get animatedIconURL(): string | undefined;
    /**
     * URL to the server's banner
     */
    get bannerURL(): string | undefined;
    /**
     * Own member object for this server
     */
    get member(): ServerMember | undefined;
    /**
     * Permission the currently authenticated user has against this server
     */
    get permission(): bigint;
    /**
     * Check whether we have a given permission in a server
     * @param permission Permission Names
     * @returns Whether we have this permission
     */
    havePermission(...permission: (keyof typeof Permission)[]): boolean;
    /**
     * Check whether we have at least one of the given permissions in a server
     * @param permission Permission Names
     * @returns Whether we have one of the permissions
     */
    orPermission(...permission: (keyof typeof Permission)[]): boolean;
    /**
     * Helper function to retrieve cached server member by their ID in this server
     * @param userId User's ID
     * @returns Server Member (if cached)
     */
    getMember(userId: string): ServerMember | undefined;
    /**
     * @param params
     * @returns This server's tracked actions, members and users
     */
    getAuditLogs(params?: (APIRoutes & {
        method: "get";
        path: "/servers/{target}/audit_logs";
        parts: 3;
    })["params"]): Promise<{
        audit_logs: AuditLogEntry[];
        users: User[];
        members: ServerMember[];
    }>;
    /**
     * Create a channel
     * @param data Channel create route data
     * @returns The newly-created channel
     */
    createChannel(data: DataCreateServerChannel): Promise<Channel>;
    /**
     * Edit a server
     * @param data Changes
     */
    edit(data: DataEditServer): Promise<void>;
    /**
     * Set ordering of roles
     * @param roleIds Role IDs
     */
    setRoleOrdering(roleIds: string[]): Promise<void>;
    /**
     * Delete the underlying server
     * @param leaveEvent Whether we are leaving
     */
    $delete(leaveEvent?: boolean): void;
    /**
     * Delete or leave a server
     * @param leaveSilently Whether to not send a message on leave
     */
    delete(leaveSilently?: boolean): Promise<void>;
    /**
     * Mark a server as read
     */
    ack(): Promise<void>;
    /**
     * Ban user from this server
     * @param user User
     * @param options Ban options
     */
    banUser(user: string | User | ServerMember, options?: DataBanCreate): Promise<ServerBan>;
    /**
     * Kick user from this server
     * @param user User
     */
    kickUser(user: string | User | ServerMember): Promise<void>;
    /**
     * Pardon user's ban
     * @param user User
     */
    unbanUser(user: string | User): Promise<void>;
    /**
     * Fetch a server's invites
     * @returns An array of the server's invites
     */
    fetchInvites(): Promise<ChannelInvite[]>;
    /**
     * Fetch a server's bans
     * @returns An array of the server's bans.
     */
    fetchBans(): Promise<ServerBan[]>;
    /**
     * Set role permissions
     * @param roleId Role Id, set to 'default' to affect all users
     * @param permissions Permission value
     */
    setPermissions(roleId: string | undefined, permissions: Override | number): Promise<APIServer>;
    /**
     * Create role
     * @param name Role name
     */
    createRole(name: string): Promise<{
        id: string;
        role: Role;
    }>;
    /**
     * Edit a role
     * @param roleId Role ID
     * @param data Role editing route data
     */
    editRole(roleId: string, data: DataEditRole): Promise<ServerRole>;
    /**
     * Delete role
     * @param roleId Role ID
     */
    deleteRole(roleId: string): Promise<void>;
    /**
     * Fetch a server member
     * @param user User
     * @returns Server member object
     */
    fetchMember(user: User | string): Promise<ServerMember>;
    syncMembers(excludeOffline?: boolean): Promise<void>;
    /**
     * Reset member sync status
     */
    resetSyncStatus(): void;
    /**
     * Fetch a server's members
     * @returns List of the server's members and their user objects
     */
    fetchMembers(): Promise<{
        members: ServerMember[];
        users: User[];
    }>;
    /**
     * Query members from a server by name
     * @param query Name
     * @returns List of the server's members and their user objects
     */
    queryMembersExperimental(query: string): Promise<{
        members: ServerMember[];
        users: User[];
    }>;
    /**
     * Create an emoji on the server
     * @param autumnId Autumn Id
     * @param options Options
     */
    createEmoji(autumnId: string, options: Omit<DataCreateEmoji, "parent">): Promise<Emoji>;
    /**
     * Fetch a server's emoji
     * @returns List of server emoji
     */
    fetchEmojis(): Promise<Emoji[]>;
    /**
     * All emojis tied to this server
     */
    get emojis(): Emoji[];
    /**
     * Delete emoji
     * @param emojiId Emoji ID
     */
    deleteEmoji(emojiId: string): Promise<void>;
    /**
     * The voice status of a server. Screenshare supersedes video, video
     * supersedes voice, and voice supersedes none. This getter takes the highest
     * priority status from all channels in the server.
     */
    get voiceStatus(): VoiceStatus;
    /**
     * Add server to the discover request queue
     */
    requestDiscover(): Promise<void>;
    /**
     * Get the status of the discover request for this server
     * @returns The discovery request for this server if one exists
     */
    discoverRequestStatus(): Promise<DiscoverRequest>;
    /**
     * Cancel the discover request for this server
     *
     * This cannot be used to remove servers from discover that have already been accepted
     * and should only be called on servers that have an outstanding discover request.
     */
    cancelDiscoverRequest(): Promise<void>;
}
//# sourceMappingURL=Server.d.ts.map