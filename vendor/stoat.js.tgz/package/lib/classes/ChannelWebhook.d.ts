import { DataEditWebhook } from "stoat-api";
import type { ChannelWebhookCollection } from "../collections/ChannelWebhookCollection.js";
import type { Channel } from "./Channel.js";
import type { File } from "./File.js";
/**
 * Channel Webhook Class
 */
export declare class ChannelWebhook {
    #private;
    readonly id: string;
    /**
     * Construct Channel Webhook
     * @param collection Collection
     * @param id Webhook
     */
    constructor(collection: ChannelWebhookCollection, id: string);
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Webhook name
     */
    get name(): string;
    /**
     * Webhook avatar
     */
    get avatar(): File | undefined;
    /**
     * Webhook avatar URL
     */
    get avatarURL(): string | undefined;
    /**
     * Channel ID this webhook belongs to
     */
    get channelId(): string;
    /**
     * Channel this webhook belongs to
     */
    get channel(): Channel | undefined;
    /**
     * Secret token for sending messages to this webhook
     */
    get token(): string;
    /**
     * Edit this webhook
     */
    edit(data: DataEditWebhook): Promise<void>;
    /**
     * Delete this webhook
     */
    delete(): Promise<void>;
}
//# sourceMappingURL=ChannelWebhook.d.ts.map