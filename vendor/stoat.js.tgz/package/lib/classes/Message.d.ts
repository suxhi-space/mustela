import type { ReactiveMap } from "@solid-primitives/map";
import type { ReactiveSet } from "@solid-primitives/set";
import type { Message as APIMessage, MessageWebhook as APIMessageWebhook, DataEditMessage, DataMessageSend, Masquerade } from "stoat-api";
import type { Client } from "../Client.js";
import type { MessageCollection } from "../collections/MessageCollection.js";
import type { Channel } from "./Channel.js";
import { File } from "./File.js";
import type { MessageEmbed } from "./MessageEmbed.js";
import type { Server } from "./Server.js";
import type { ServerMember } from "./ServerMember.js";
import { ServerRole } from "./ServerRole.js";
import type { SystemMessage } from "./SystemMessage.js";
import type { User } from "./User.js";
/**
 * Message Class
 */
export declare class Message {
    #private;
    readonly id: string;
    /**
     * Construct Message
     * @param collection Collection
     * @param id Message Id
     */
    constructor(collection: MessageCollection, id: string);
    /**
     * Whether this object exists
     */
    get $exists(): boolean;
    /**
     * Time when this message was posted
     */
    get createdAt(): Date;
    /**
     * Absolute pathname to this message in the client
     */
    get path(): string;
    /**
     * URL to this message
     */
    get url(): string | undefined;
    /**
     * Nonce value
     */
    get nonce(): string | undefined;
    /**
     * Id of channel this message was sent in
     */
    get channelId(): string;
    /**
     * Channel this message was sent in
     */
    get channel(): Channel | undefined;
    /**
     * Server this message was sent in
     */
    get server(): Server | undefined;
    /**
     * Member this message was sent by
     */
    get member(): ServerMember | undefined;
    /**
     * Id of user or webhook this message was sent by
     */
    get authorId(): string | undefined;
    /**
     * User this message was sent by
     */
    get author(): User | undefined;
    /**
     * Webhook information for this message
     */
    get webhook(): MessageWebhook | undefined;
    /**
     * Content
     */
    get content(): string;
    /**
     * Content converted to plain text
     */
    get contentPlain(): string;
    /**
     * System message content
     */
    get systemMessage(): SystemMessage | undefined;
    /**
     * Attachments
     */
    get attachments(): File[] | undefined;
    /**
     * Time at which this message was edited
     */
    get editedAt(): Date | undefined;
    /**
     * Embeds
     */
    get embeds(): MessageEmbed[] | undefined;
    /**
     * IDs of users this message mentions
     */
    get mentionIds(): string[] | undefined;
    /**
     * IDs of roles this message mentions
     */
    get roleMentionIds(): string[] | undefined;
    /**
     * Roles this message mentions
     */
    get roleMentions(): ServerRole[] | undefined;
    /**
     * Whether this message mentions us
     */
    get mentioned(): boolean;
    /**
     * IDs of messages this message replies to
     */
    get replyIds(): string[] | undefined;
    /**
     * Reactions
     */
    get reactions(): ReactiveMap<string, ReactiveSet<string>>;
    /**
     * Interactions
     */
    get interactions(): APIMessage["interactions"];
    /**
     * Masquerade
     */
    get masquerade(): Masquerade | undefined;
    /**
     * Whether this message is pinned
     */
    get pinned(): boolean;
    /**
     * Flags
     */
    get flags(): number;
    /**
     * Get the username for this message
     */
    get username(): string | undefined;
    /**
     * Get the role colour for this message
     */
    get roleColour(): string | null | undefined;
    /**
     * Get the role colour for this message
     */
    get iconRole(): ServerRole | null | undefined;
    /**
     * Get the avatar URL for this message
     */
    get avatarURL(): string | undefined;
    /**
     * Get the animated avatar URL for this message
     */
    get animatedAvatarURL(): string | undefined;
    /**
     * Avatar URL from the masquerade
     */
    get masqueradeAvatarURL(): string | undefined;
    /**
     * Whether this message has suppressed desktop/push notifications
     */
    get isSuppressed(): boolean;
    /**
     * Edit a message
     * @param data Message edit route data
     */
    edit(data: DataEditMessage): Promise<APIMessage>;
    /**
     * Delete a message
     */
    delete(): Promise<void>;
    /**
     * Acknowledge this message as read
     * @param skipRateLimiter Whether to skip the internal rate limiter
     * @param skipRequest For internal updates only
     * @param skipNextMarking For internal usage only
     * @requires `SavedMessages`, `DirectMessage`, `Group`, `TextChannel`
     */
    ack(skipRateLimiter?: boolean, skipRequest?: boolean, skipNextMarking?: boolean): void;
    /**
     * Reply to Message
     */
    reply(data: string | (Omit<DataMessageSend, "nonce"> & {
        nonce?: string;
    }), mention?: boolean): Promise<Message> | undefined;
    /**
     * Clear all reactions from this message
     */
    clearReactions(): Promise<void>;
    /**
     * React to a message
     * @param emoji Unicode or emoji ID
     */
    react(emoji: string): Promise<void>;
    /**
     * Un-react from a message
     * @param emoji Unicode or emoji ID
     * @param deleteAll Remove all reactions
     */
    unreact(emoji: string, deleteAll?: boolean): Promise<void>;
    /**
     * Pin the message
     */
    pin(): Promise<void>;
    /**
     * Unpin the message
     */
    unpin(): Promise<void>;
}
/**
 * Message Webhook Class
 */
export declare class MessageWebhook {
    #private;
    readonly id: string;
    readonly name: string;
    readonly avatar?: File;
    /**
     * Construct Message Webhook
     * @param client Client
     * @param webhook Webhook data
     */
    constructor(client: Client, webhook: APIMessageWebhook, id: string);
    /**
     * Get the avatar URL for this message webhook
     */
    get avatarURL(): string;
}
//# sourceMappingURL=Message.d.ts.map