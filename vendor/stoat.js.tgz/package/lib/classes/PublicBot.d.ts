import type { PublicBot as APIPublicBot } from "stoat-api";
import type { Client } from "../Client.js";
import { Channel } from "./Channel.js";
import { File } from "./File.js";
import { Server } from "./Server.js";
/**
 * Public Bot Class
 */
export declare class PublicBot {
    #private;
    readonly id: string;
    readonly username: string;
    readonly avatar?: File;
    readonly description?: string;
    /**
     * Construct Public Bot
     * @param client Client
     * @param data Data
     */
    constructor(client: Client, data: APIPublicBot);
    /**
     * Add the bot to a server
     * @param server Server
     */
    addToServer(server: Server | string): void;
    /**
     * Add the bot to a group
     * @param group Group
     */
    addToGroup(group: Channel | string): void;
}
//# sourceMappingURL=PublicBot.d.ts.map