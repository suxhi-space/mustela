import type { Invite, InviteResponse } from "stoat-api";
import type { Client } from "../Client.js";
import type { ServerFlags } from "../hydration/server.js";
import { File } from "./File.js";
import type { Server } from "./Server.js";
/**
 * Public Channel Invite
 */
export declare abstract class PublicChannelInvite {
    protected client?: Client;
    readonly type: Invite["type"] | "None";
    /**
     * Construct Channel Invite
     * @param client Client
     * @param type Type
     */
    constructor(client?: Client, type?: Invite["type"] | "None");
    /**
     * Create an Invite from an API Invite Response
     * @param client Client
     * @param invite Data
     * @returns Invite
     */
    static from(client: Client, invite: InviteResponse): PublicChannelInvite;
}
/**
 * Public invite of unknown type
 */
export declare class UnknownPublicInvite extends PublicChannelInvite {
}
/**
 * Public Server Invite
 */
export declare class ServerPublicInvite extends PublicChannelInvite {
    readonly code: string;
    readonly userName: string;
    readonly userAvatar?: File;
    readonly serverId: string;
    readonly serverName: string;
    readonly serverIcon?: File;
    readonly serverBanner?: File;
    readonly serverFlags: ServerFlags;
    readonly memberCount: number;
    readonly channelId: string;
    readonly channelName: string;
    readonly channelDescription?: string;
    /**
     * Construct Server Invite
     * @param client Client
     * @param invite Invite
     */
    constructor(client: Client, invite: InviteResponse & {
        type: "Server";
    });
    /**
     * Server (if it exists in cache)
     */
    get server(): Server | undefined;
    /**
     * Join the server
     */
    join(): Promise<Server>;
}
//# sourceMappingURL=PublicInvite.d.ts.map