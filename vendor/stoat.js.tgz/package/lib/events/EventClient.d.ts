import type { Accessor } from "solid-js";
import { AsyncEventEmitter } from "@vladfrangu/async_event_emitter";
import type { Error as StoatError } from "stoat-api";
import type { ProtocolV1 } from "./v1.js";
/**
 * Available protocols to connect with
 */
export type AvailableProtocols = 1;
/**
 * Protocol mapping
 */
type Protocols = {
    1: ProtocolV1;
};
/**
 * Select a protocol by its key
 */
export type EventProtocol<T extends AvailableProtocols> = Protocols[T];
/**
 * All possible event client states.
 */
export declare enum ConnectionState {
    Idle = 0,
    Connecting = 1,
    Connected = 2,
    Disconnected = 3
}
/**
 * Event client options object
 */
export interface EventClientOptions {
    /**
     * Whether to log events
     * @default false
     */
    debug: boolean;
    /**
     * Time in seconds between Ping packets sent to the server
     * @default 30
     */
    heartbeatInterval: number;
    /**
     * Maximum time in seconds between Ping and corresponding Pong
     * @default 10
     */
    pongTimeout: number;
    /**
     * Maximum time in seconds between init and first message
     * @default 10
     */
    connectTimeout: number;
}
/**
 * Events provided by the client.
 */
type Events<T extends AvailableProtocols, P extends EventProtocol<T>> = {
    error: [error: StoatError | Error | Event];
    event: [event: P["server"]];
    state: [state: ConnectionState];
};
/**
 * Simple wrapper around the Revolt websocket service.
 */
export declare class EventClient<T extends AvailableProtocols> extends AsyncEventEmitter<Events<T, EventProtocol<T>>> {
    #private;
    readonly options: EventClientOptions;
    readonly ping: Accessor<number>;
    readonly state: Accessor<ConnectionState>;
    /**
     * Create a new event client.
     * @param protocolVersion Target protocol version
     * @param transportFormat Communication format
     * @param options Configuration options
     */
    constructor(protocolVersion: T, transportFormat?: "json", options?: Partial<EventClientOptions>);
    /**
     * Set the current state
     * @param state state
     */
    private setState;
    /**
     * Clear all pending connection timers. Call on disconnect.
     * Idempotent — safe to call multiple times.
     */
    private clearTimers;
    /**
     * Connect to the websocket service.
     * @param uri WebSocket URI
     * @param token Authentication token
     */
    connect(uri: string, token: string): void;
    /**
     * Dispose the websocket client.
     */
    dispose(): void;
    /**
     * Disconnect the websocket client.
     */
    disconnect(): void;
    /**
     * Send an event to the server.
     * @param event Event
     */
    send(event: EventProtocol<T>["client"]): void;
    /**
     * Handle events intended for client before passing them along.
     * @param event Event
     */
    handle(event: EventProtocol<T>["server"]): void;
    /**
     * Last error encountered by events client
     */
    get lastError(): {
        type: "socket";
        data: Event;
    } | {
        type: "revolt";
        data: StoatError;
    } | {
        type: "protocol";
        data: Error;
    } | undefined;
}
export {};
//# sourceMappingURL=EventClient.d.ts.map