import type { SetStoreFunction } from "solid-js/store";
import { type Hydrators } from "../hydration/index.js";
/**
 * Wrapper around Solid.js store
 */
export declare class ObjectStorage<T> {
    private store;
    readonly set: SetStoreFunction<Record<string, T>>;
    /**
     * Create new object storage
     */
    constructor();
    /**
     * Get object by ID
     * @param id ID
     * @returns Object
     */
    get(id: string): T | undefined;
    /**
     * Hydrate some data into storage
     * @param id ID
     * @param type Hydration type
     * @param context Context
     * @param data Input Data
     */
    hydrate(id: string, type: keyof Hydrators, context: unknown, data?: unknown): void;
    /**
     * Hydrate some data without putting it into storage. Call {@link add}
     * afterwards to add the hydrated value into storage.
     * @param type Hydration type
     * @param context Context
     * @param data Input Data
     * @returns The hydrated type
     */
    hydrateOnly(type: keyof Hydrators, context: unknown, data: object): T;
    /**
     * Add a previously hydrated object to the storage
     * @param id ID
     * @param toAdd Hydrated object
     */
    add(id: string, toAdd: T): void;
}
//# sourceMappingURL=ObjectStorage.d.ts.map