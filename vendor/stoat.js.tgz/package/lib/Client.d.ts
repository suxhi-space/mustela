import type { Accessor } from "solid-js";
import { AsyncEventEmitter } from "@vladfrangu/async_event_emitter";
import { API } from "stoat-api";
import type { DataLogin, RevoltConfig, Role, Error as StoatError } from "stoat-api";
import type { Channel } from "./classes/Channel.js";
import type { Emoji } from "./classes/Emoji.js";
import type { Message } from "./classes/Message.js";
import type { Server } from "./classes/Server.js";
import type { ServerMember } from "./classes/ServerMember.js";
import type { User, UserLimits } from "./classes/User.js";
import { AccountCollection } from "./collections/AccountCollection.js";
import { BotCollection } from "./collections/BotCollection.js";
import { ChannelCollection } from "./collections/ChannelCollection.js";
import { ChannelUnreadCollection } from "./collections/ChannelUnreadCollection.js";
import { ChannelWebhookCollection } from "./collections/ChannelWebhookCollection.js";
import { EmojiCollection } from "./collections/EmojiCollection.js";
import { MessageCollection } from "./collections/MessageCollection.js";
import { ServerCollection } from "./collections/ServerCollection.js";
import { ServerMemberCollection } from "./collections/ServerMemberCollection.js";
import { SessionCollection } from "./collections/SessionCollection.js";
import { UserCollection } from "./collections/UserCollection.js";
import { EventClient, type EventClientOptions } from "./events/EventClient.js";
import { ProtocolV1 } from "./events/v1.js";
import type { HydratedChannel } from "./hydration/channel.js";
import type { HydratedEmoji } from "./hydration/emoji.js";
import type { HydratedMessage } from "./hydration/message.js";
import type { HydratedServer } from "./hydration/server.js";
import type { HydratedServerMember } from "./hydration/serverMember.js";
import type { HydratedUser } from "./hydration/user.js";
export type Session = {
    _id: string;
    token: string;
    user_id: string;
} | string;
/**
 * Events provided by the client
 */
export type Events = {
    error: [error: StoatError | Error | Event];
    connected: [];
    connecting: [];
    disconnected: [];
    ready: [];
    logout: [];
    policyChanges: [
        policyChanges: ProtocolV1["types"]["policyChange"][],
        acknowledge: () => Promise<void>
    ];
    messageCreate: [message: Message];
    messageUpdate: [message: Message, previousMessage: HydratedMessage];
    messageDelete: [message: HydratedMessage];
    messageDeleteBulk: [messages: HydratedMessage[], channel?: Channel];
    messageReactionAdd: [message: Message, userId: string, emoji: string];
    messageReactionRemove: [message: Message, userId: string, emoji: string];
    messageReactionRemoveEmoji: [message: Message, emoji: string];
    channelCreate: [channel: Channel];
    channelUpdate: [channel: Channel, previousChannel: HydratedChannel];
    channelDelete: [channel: HydratedChannel];
    channelGroupJoin: [channel: Channel, user: User];
    channelGroupLeave: [channel: Channel, user?: User];
    channelStartTyping: [channel: Channel, user?: User];
    channelStopTyping: [channel: Channel, user?: User];
    channelAcknowledged: [channel: Channel, messageId: string];
    serverCreate: [server: Server];
    serverUpdate: [server: Server, previousServer: HydratedServer];
    serverDelete: [server: HydratedServer];
    serverLeave: [server: HydratedServer];
    serverRoleUpdate: [server: Server, roleId: string, previousRole: Role];
    serverRoleRanksUpdate: [server: Server, ranks: string[]];
    serverRoleDelete: [server: Server, roleId: string, role: Role];
    serverMemberUpdate: [
        member: ServerMember,
        previousMember: HydratedServerMember
    ];
    serverMemberJoin: [member: ServerMember];
    serverMemberLeave: [member: HydratedServerMember];
    userUpdate: [user: User, previousUser: HydratedUser];
    userSettingsUpdate: [id: string, update: Record<string, [number, string]>];
    entitlementsUpdate: [entitlements: ProtocolV1["types"]["entitlement"][]];
    emojiCreate: [emoji: Emoji];
    emojiDelete: [emoji: HydratedEmoji];
    userSlowmodes: [];
};
/**
 * Client options object
 */
export type ClientOptions = Partial<EventClientOptions> & {
    /**
     * Base URL of the API server
     */
    baseURL: string;
    /**
     * Whether to allow partial objects to emit from events
     * @default false
     */
    partials: boolean;
    /**
     * Whether to eagerly fetch users and members for incoming events
     * @default true
     * @deprecated
     */
    eagerFetching: boolean;
    /**
     * Whether to automatically sync unreads information
     * @default false
     */
    syncUnreads: boolean;
    /**
     * Whether to reconnect when disconnected
     * @default true
     */
    autoReconnect: boolean;
    /**
     * Whether to rewrite sent messages that include identifiers such as @silent
     * @default true
     */
    messageRewrites: boolean;
    /**
     * Retry delay function
     * @param retryCount Count
     * @returns Delay in seconds
     * @default (2^x-1) ±20%
     */
    retryDelayFunction(retryCount: number): number;
    /**
     * Check whether a channel is muted
     * @param channel Channel
     * @return Whether it is muted or through inheritance
     * @default false
     */
    channelIsMuted(channel: Channel): boolean;
    /**
     * Check whether a channel is exclusively muted (irrespective of server)
     * @param channel Channel
     * @return Whether it is exclusively muted
     * @default false
     */
    channelExclusiveMuted(channel: Channel): boolean;
};
/**
 * Stoat.js Clients
 */
export declare class Client extends AsyncEventEmitter<Events> {
    #private;
    readonly account: AccountCollection;
    readonly bots: BotCollection;
    readonly channels: ChannelCollection;
    readonly channelUnreads: ChannelUnreadCollection;
    readonly channelWebhooks: ChannelWebhookCollection;
    readonly emojis: EmojiCollection;
    readonly messages: MessageCollection;
    readonly servers: ServerCollection;
    readonly serverMembers: ServerMemberCollection;
    readonly sessions: SessionCollection;
    readonly users: UserCollection;
    readonly api: API;
    readonly options: ClientOptions;
    readonly events: EventClient<1>;
    readonly configuration: RevoltConfig | undefined;
    user: User | undefined;
    readonly ready: Accessor<boolean>;
    readonly configured: Accessor<boolean>;
    readonly connectionFailureCount: Accessor<number>;
    /**
     * Entitlements the current user holds, as last sent by the server.
     * Note that passing an expiration date will NOT remove its data,
     * so you may need to keep track of expiration yourself.
     */
    readonly entitlements: Accessor<ProtocolV1["types"]["entitlement"][]>;
    /**
     * Create Stoat.js Client
     * @param configuration Deprecated - Please use `Client.initConfig` if you need to override config.
     */
    constructor(options?: Partial<ClientOptions>, configuration?: RevoltConfig);
    /**
     * Current session id
     */
    get sessionId(): string | undefined;
    /**
     * Get authentication header
     */
    get authenticationHeader(): [string, string];
    /**
     * Connect to Revolt
     */
    connect(): void;
    /**
     * Fetches the server config. This is called automatically by `login()` or `loginBot()`,
     * but you can call it first manually if you need to override any config options.
     *
     * Override example:
     * ```ts
     * await client.initConfig((config) => {
     *   config.ws = "wss://example.com";
     * });
     * ```
     */
    initConfig(preConfig?: (config: RevoltConfig) => void): Promise<void>;
    /**
     * Log in with auth data, creating a new session in the process.
     * @param details Login data object
     * @returns An on-boarding function if on-boarding is required, undefined otherwise
     */
    login(details: DataLogin): Promise<void>;
    /**
     * Use an existing session
     */
    useExistingSession(session: Session): void;
    /**
     * Log in as a bot
     * @param token Bot token
     */
    loginBot(token: string): Promise<void>;
    /**
     * Log out of current session
     *
     * This function prepares the client for disposal by removing all event listeners and killing the events socket.
     */
    logout(): Promise<void>;
    /**
     * Replace the current user's entitlements, from the events socket
     * @internal
     */
    setEntitlements(entitlements: ProtocolV1["types"]["entitlement"][]): void;
    /**
     * Prepare a markdown-based message to be displayed to the user as plain text.
     * @param source Source markdown text
     * @returns Modified plain text
     */
    markdownToText(source: string): string;
    /**
     * Prepare a markdown-based message to be displayed to the user as plain text. This method will fetch each user or channel if they are missing. Useful for serviceworkers.
     * @param source Source markdown text
     * @returns Modified plain text
     */
    markdownToTextFetch(source: string): Promise<string>;
    /**
     * Proxy a file through January.
     * @param url URL to proxy
     * @returns Proxied media URL
     */
    proxyFile(url: string): string | undefined;
    /**
     * Upload a file
     * @param tag Tag
     * @param file File
     * @param uploadUrl Media server upload route
     */
    uploadFile(tag: string, file: File, uploadUrl?: string): Promise<string>;
    /**
     * Backend enforced limits for the logged in user
     */
    get limits(): UserLimits | undefined;
}
//# sourceMappingURL=Client.d.ts.map