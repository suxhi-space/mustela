import type { Channel as APIChannel } from "stoat-api";
import { Channel } from "../classes/Channel.js";
import { User } from "../classes/User.js";
import type { HydratedChannel } from "../hydration/channel.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Channels
 */
export declare class ChannelCollection extends ClassCollection<Channel, HydratedChannel> {
    /**
     * Delete an object
     * @param id Id
     */
    delete(id: string): void;
    /**
     * Fetch channel by ID
     * @param id Id
     * @returns Channel
     */
    fetch(id: string): Promise<Channel>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     * @param isNew Whether this object is new
     */
    getOrCreate(id: string, data: APIChannel, isNew?: boolean): Channel;
    /**
     * Get or return partial
     * @param id Id
     */
    getOrPartial(id: string): Channel | undefined;
    /**
     * Create a group
     * @param name Group name
     * @param users Users to add
     * @returns The newly-created group
     */
    createGroup(name: string, users: (User | string)[]): Promise<Channel>;
}
//# sourceMappingURL=ChannelCollection.d.ts.map