import type { User as APIUser } from "stoat-api";
import type { Client } from "../Client.js";
import { User } from "../classes/User.js";
import type { HydratedUser } from "../hydration/user.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Users
 */
export declare class UserCollection extends ClassCollection<User, HydratedUser> {
    /**
     * Construct User collection
     */
    constructor(client: Client);
    /**
     * Fetch user by ID
     * @param id Id
     * @returns User
     */
    fetch(id: string): Promise<User>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     */
    getOrCreate(id: string, data: APIUser): User;
    /**
     * Get or return partial
     * @param id Id
     */
    getOrPartial(id: string): User | undefined;
    /**
     * Hydrate a new user if it is not in the collection yet. This function does
     * not add the user to the store, make sure you call {@link addHydratedUser}
     * afterwards. This function is particularly useful when adding many users
     * asynchronously. See Server.syncMembers for an example of this in use.
     * @param id The ID of the user
     * @param data The API object for a user
     * @returns The HydratedUser, or undefined if the user is in the collection
     */
    hydrateIfNotHas(id: string, data: APIUser): HydratedUser | undefined;
    /**
     * Add a pre-hydrated user to this collection.
     * @param user A hydrated user
     * @returns The user instance
     */
    addHydratedUser(user: HydratedUser): User;
}
//# sourceMappingURL=UserCollection.d.ts.map