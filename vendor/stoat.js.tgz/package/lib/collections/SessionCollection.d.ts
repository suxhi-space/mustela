import type { SessionInfo } from "stoat-api";
import { MFATicket } from "../classes/MFA.js";
import { Session } from "../classes/Session.js";
import type { HydratedSession } from "../hydration/session.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Sessions
 */
export declare class SessionCollection extends ClassCollection<Session, HydratedSession> {
    /**
     * Fetch active sessions
     * @returns List of sessions
     */
    fetch(): Promise<Session[]>;
    /**
     * Delete all sessions, optionally including self
     * @param revokeSelf Whether to remove current session too
     */
    deleteAll(ticket: MFATicket, revokeSelf?: boolean): Promise<void>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     * @returns Session
     */
    getOrCreate(id: string, data: SessionInfo): Session;
}
//# sourceMappingURL=SessionCollection.d.ts.map