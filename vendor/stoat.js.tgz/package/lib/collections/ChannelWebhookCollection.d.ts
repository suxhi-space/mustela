import type { Webhook } from "stoat-api";
import { ChannelWebhook } from "../classes/ChannelWebhook.js";
import type { HydratedChannelWebhook } from "../hydration/channelWebhook.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Channel Webhooks
 */
export declare class ChannelWebhookCollection extends ClassCollection<ChannelWebhook, HydratedChannelWebhook> {
    /**
     * Fetch webhook by ID
     * @param id Id
     * @returns Webhook
     */
    fetch(id: string): Promise<ChannelWebhook>;
    /**
     * Create webhook with ID and token
     * @param id Id
     * @param token Token
     * @returns Webhook
     */
    fromToken(id: string, token: string): Promise<ChannelWebhook>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     */
    getOrCreate(id: string, data: Webhook): ChannelWebhook;
}
//# sourceMappingURL=ChannelWebhookCollection.d.ts.map