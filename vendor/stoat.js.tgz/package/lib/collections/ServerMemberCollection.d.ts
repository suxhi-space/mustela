import type { Member, MemberCompositeKey } from "stoat-api";
import { ServerMember } from "../classes/ServerMember.js";
import type { HydratedServerMember } from "../hydration/serverMember.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Server Members
 */
export declare class ServerMemberCollection extends ClassCollection<ServerMember, HydratedServerMember> {
    /**
     * Check if member exists by composite key
     * @param id Id
     * @returns Whether it exists
     */
    hasByKey(id: MemberCompositeKey): boolean;
    /**
     * Get member by composite key
     * @param id Id
     * @returns Member
     */
    getByKey(id: MemberCompositeKey): ServerMember | undefined;
    /**
     * check partial status by composite key
     * @param id Id
     * @returns Member
     */
    isPartialByKey(id: MemberCompositeKey): boolean;
    /**
     * Fetch server member by Id
     * @param serverId Server Id
     * @param userId User Id
     * @returns Message
     */
    fetch(serverId: string, userId: string): Promise<ServerMember>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     */
    getOrCreate(id: MemberCompositeKey, data: Member): ServerMember;
    /**
     * Get or return partial
     * @param id Id
     */
    getOrPartial(id: MemberCompositeKey): ServerMember | undefined;
    /**
     * Hydrate a new server member if it is not in the collection yet. This
     * function does not add the server member to the store, make sure you call
     * {@link addHydratedServerMember} afterwards. This function is particularly
     * useful when adding many server members asynchronously. See
     * Server.syncMembers for an example of this in use.
     * @param id The ID of the server member
     * @param data The API object for a server member
     * @returns The HydratedServerMember, or undefined if the user is in the collection
     */
    hydrateIfNotHas(id: MemberCompositeKey, data: Member): HydratedServerMember | undefined;
    /**
     * Add a pre-hydrated server member to this collection.
     * @param user A hydrated server member
     * @returns The server member instance
     */
    addHydratedServerMember(member: HydratedServerMember): ServerMember;
}
//# sourceMappingURL=ServerMemberCollection.d.ts.map