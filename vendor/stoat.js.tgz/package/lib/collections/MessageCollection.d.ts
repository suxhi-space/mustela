import type { Message as APIMessage } from "stoat-api";
import { Message } from "../classes/Message.js";
import type { HydratedMessage } from "../hydration/message.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Messages
 */
export declare class MessageCollection extends ClassCollection<Message, HydratedMessage> {
    /**
     * Fetch message by Id
     * @param channelId Channel Id
     * @param messageId Message Id
     * @returns Message
     */
    fetch(channelId: string, messageId: string): Promise<Message>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     * @param isNew Whether this object is new
     */
    getOrCreate(id: string, data: APIMessage, isNew?: boolean): Message;
    /**
     * Get or return partial
     * @param id Id
     */
    getOrPartial(id: string): Message | undefined;
}
//# sourceMappingURL=MessageCollection.d.ts.map