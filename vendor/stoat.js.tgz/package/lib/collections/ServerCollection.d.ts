import type { Server as APIServer, DataCreateServer } from "stoat-api";
import { Server } from "../classes/Server.js";
import type { HydratedServer } from "../hydration/server.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Servers
 */
export declare class ServerCollection extends ClassCollection<Server, HydratedServer> {
    /**
     * Fetch server by ID
     *
     * This will not fetch channels!
     * @param id Id
     * @returns Server
     */
    fetch(id: string): Promise<Server>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     * @param isNew Whether this object is new
     */
    getOrCreate(id: string, data: APIServer, isNew?: boolean): Server;
    /**
     * Get or return partial
     * @param id Id
     */
    getOrPartial(id: string): Server | undefined;
    /**
     * Create a server
     * @param data Server options
     * @returns The newly-created server
     */
    createServer(data: DataCreateServer): Promise<Server>;
}
//# sourceMappingURL=ServerCollection.d.ts.map