import type { Emoji as APIEmoji } from "stoat-api";
import { Emoji } from "../classes/Emoji.js";
import type { HydratedEmoji } from "../hydration/emoji.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Emoji
 */
export declare class EmojiCollection extends ClassCollection<Emoji, HydratedEmoji> {
    /**
     * Fetch emoji by ID
     * @param id Id
     * @returns Emoji
     */
    fetch(id: string): Promise<Emoji>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     * @param isNew Whether this object is new
     */
    getOrCreate(id: string, data: APIEmoji, isNew?: boolean): Emoji;
    /**
     * Get or return partial
     * @param id Id
     */
    getOrPartial(id: string): Emoji | undefined;
}
//# sourceMappingURL=EmojiCollection.d.ts.map