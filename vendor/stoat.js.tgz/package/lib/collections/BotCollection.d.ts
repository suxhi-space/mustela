import type { Bot as APIBot } from "stoat-api";
import { Bot } from "../classes/Bot.js";
import { PublicBot } from "../classes/PublicBot.js";
import type { HydratedBot } from "../hydration/bot.js";
import { ClassCollection } from "./Collection.js";
/**
 * Collection of Bots
 */
export declare class BotCollection extends ClassCollection<Bot, HydratedBot> {
    /**
     * Fetch bot by ID
     * @param id Id
     * @returns Bot
     */
    fetch(id: string): Promise<Bot>;
    /**
     * Fetch owned bots
     * @returns List of bots
     */
    fetchOwned(): Promise<Bot[]>;
    /**
     * Fetch public bot by ID
     * @param id Id
     * @returns Public Bot
     */
    fetchPublic(id: string): Promise<PublicBot>;
    /**
     * Get or create
     * @param id Id
     * @param data Data
     * @returns Bot
     */
    getOrCreate(id: string, data: APIBot): Bot;
    /**
     * Create a bot
     * @param name Bot name
     * @returns The newly-created bot
     */
    createBot(name: string): Promise<Bot>;
}
//# sourceMappingURL=BotCollection.d.ts.map