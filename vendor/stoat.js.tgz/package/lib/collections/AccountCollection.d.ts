import type { DataCreateAccount, WebPushSubscription } from "stoat-api";
import type { Client } from "../Client.js";
import { MFA, MFATicket } from "../classes/MFA.js";
/**
 * Utility functions for working with accounts
 */
export declare class AccountCollection {
    readonly client: Client;
    /**
     * Create generic class collection
     * @param client Client
     */
    constructor(client: Client);
    /**
     * Fetch current account email
     * @returns Email
     */
    fetchEmail(): Promise<string>;
    /**
     * Create a MFA helper
     */
    mfa(): Promise<MFA>;
    /**
     * Create a new account
     * @param data Account details
     */
    create(data: DataCreateAccount): Promise<void>;
    /**
     * Resend email verification
     * @param email Email
     * @param captcha Captcha if enabled
     */
    reverify(email: string, captcha?: string): Promise<void>;
    /**
     * Send password reset email
     * @param email Email
     * @param captcha Captcha if enabled
     */
    resetPassword(email: string, captcha?: string): Promise<void>;
    /**
     * Verify an account given the code
     * @param code Verification code
     */
    verify(code: string): Promise<unknown>;
    /**
     * Confirm account deletion
     * @param token Deletion token
     */
    confirmDelete(token: string): Promise<void>;
    /**
     * Confirm password reset
     * @param token Token
     * @param newPassword New password
     * @param removeSessions Whether to remove existing sessions
     */
    confirmPasswordReset(token: string, newPassword: string, removeSessions: boolean): Promise<void>;
    /**
     * Change account password
     * @param newPassword New password
     * @param currentPassword Current password
     */
    changePassword(newPassword: string, currentPassword: string): Promise<void>;
    /**
     * Change account email
     * @param newEmail New email
     * @param currentPassword Current password
     * @param ticket MFA ticket, mandatory if account has MFA enabled
     */
    changeEmail(newEmail: string, currentPassword: string, ticket?: MFATicket): Promise<void>;
    /**
     * Fetch settings
     * @param keys Keys
     * @returns Settings
     */
    fetchSettings(keys: string[]): Promise<Record<string, [number, string]>>;
    /**
     * Set settings
     * @param settings Settings
     * @param timestamp Timestamp
     */
    setSettings(settings: Record<string, any>, timestamp?: number): Promise<void>;
    /**
     * Create a new Web Push subscription
     * @param subscription Subscription
     */
    webPushSubscribe(subscription: WebPushSubscription): Promise<void>;
    /**
     * Remove existing Web Push subscription
     */
    webPushUnsubscribe(): Promise<void>;
}
//# sourceMappingURL=AccountCollection.d.ts.map