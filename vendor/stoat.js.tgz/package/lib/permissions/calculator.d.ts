import { Channel, Client, Server, ServerMember } from "../index.js";
/**
 * Check whether `b` is present in `a`
 * @param a Input A
 * @param b Inputs (OR'd together)
 */
export declare function bitwiseAndEq(a: bigint, ...b: bigint[]): boolean;
/**
 * Calculate permissions against a given object
 * @param target Target object to check permissions against
 * @param options Additional options to use when calculating
 */
export declare function calculatePermission(client: Client, target: Channel | Server, options?: {
    /**
     * Pretend to be another ServerMember
     */
    member?: ServerMember;
}): bigint;
//# sourceMappingURL=calculator.d.ts.map